-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : Dim 10 mai 2020 à 21:47
-- Version du serveur :  10.3.16-MariaDB
-- Version de PHP : 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `id13390384_antibihomebdd`
--

-- --------------------------------------------------------

--
-- Structure de la table `medecin`
--

CREATE TABLE `medecin` (
  `CODEMED` varchar(128) NOT NULL,
  `CODESPE` varchar(4) NOT NULL,
  `POSTE` varchar(128) DEFAULT NULL,
  `NOM` varchar(128) DEFAULT NULL,
  `PRENOM` char(32) DEFAULT NULL,
  `MAIL` varchar(128) DEFAULT NULL,
  `MDP` varchar(128) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `medecin`
--

INSERT INTO `medecin` (`CODEMED`, `CODESPE`, `POSTE`, `NOM`, `PRENOM`, `MAIL`, `MDP`) VALUES
('1234', 'neu', 'neuro', 'CHANAL', 'Marie', 'marie.chanal@gmail.com', 'mariechanal'),
('103', 'ALL', 'Medecin', 'Dupuy', 'Emma', 'emmadupuypro@gmail.com', 'mdp'),
('108', 'INF', 'Medecin', 'Marechal', 'Julie', 'medecinjuliemarechal@gmail.com', 'medecinTest');

-- --------------------------------------------------------

--
-- Structure de la table `mensuration`
--

CREATE TABLE `mensuration` (
  `CODEM` bigint(4) NOT NULL,
  `CODENIR` bigint(13) NOT NULL,
  `DATEM` date DEFAULT NULL,
  `POIDS` decimal(3,2) DEFAULT NULL,
  `TAILLE` decimal(3,2) DEFAULT NULL,
  `IMC` decimal(3,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mensuration`
--

INSERT INTO `mensuration` (`CODEM`, `CODENIR`, `DATEM`, `POIDS`, `TAILLE`, `IMC`) VALUES
(1, 5555555555555, '2020-04-01', 1.00, 1.00, 1.00);

-- --------------------------------------------------------

--
-- Structure de la table `pathologie`
--

CREATE TABLE `pathologie` (
  `CODEP` varchar(128) NOT NULL,
  `NOM` varchar(128) DEFAULT NULL,
  `RISQUE` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pathologie`
--

INSERT INTO `pathologie` (`CODEP`, `NOM`, `RISQUE`) VALUES
('hepa', 'hepatite A', 3),
('mono', 'mononucleose', 5),
('hepb', 'hepatite B', 2),
('sal', 'Salmonellose ', 4);

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

CREATE TABLE `patient` (
  `CODENIR` bigint(13) NOT NULL,
  `NOM` varchar(128) DEFAULT NULL,
  `PRENOM` varchar(128) DEFAULT NULL,
  `DATENAISS` date DEFAULT NULL,
  `ANTECEDENT` varchar(128) DEFAULT NULL,
  `ADRESSE` varchar(128) DEFAULT NULL,
  `CP` int(11) DEFAULT NULL,
  `VILLE` varchar(128) DEFAULT NULL,
  `TELEPHONE` int(11) DEFAULT NULL,
  `MAIL` varchar(128) DEFAULT NULL,
  `MDP` varchar(128) DEFAULT NULL,
  `JOURQUESTIONNAIRE` varchar(90) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`CODENIR`, `NOM`, `PRENOM`, `DATENAISS`, `ANTECEDENT`, `ADRESSE`, `CP`, `VILLE`, `TELEPHONE`, `MAIL`, `MDP`, `JOURQUESTIONNAIRE`) VALUES
(1111111111111, 'Etheve', 'Lucas', '2017-10-11', 'Asthme', '3 rue victor-hugo', 81100, 'Castres', 606060606, 'lucas.etheve@gmail.com', 'lucasetheve', '1 4       5'),
(2222222222222, 'Nadir', 'Samira', '2017-02-02', NULL, '3 rue de la Paix', 81100, 'Castres', 606060604, 'samira.nadir@gmail.com', 'samiranadir', '1 2 3      7'),
(5555555555555, 'Nourrisson', 'Marie', '2006-09-06', 'Aucun', '10 avenue Rebier', 81100, 'Castres', 606070606, 'marie.nourrisson@gmail.com', 'marienourrisson', ''),
(4444444444444, 'Dupuy', 'Emma', '1999-03-10', 'Asthme, allergies', '39 rue Theron Perie', 81100, 'Castres', 1673469904, 'emmadupuypro@gmail.com', 'mdp', ''),
(180104101818767, 'Dupont', 'François', '1980-10-15', 'Tabagisme', '37bis rue Charles De Gaulle', 41000, 'Blois', 600000000, 'patientfrancoisdupont@gmail.com', 'patientTest', '1 2 3 4 5 6 7'),
(12345678910, 'Paul', 'Jean', '1980-05-01', 'Asthmatique', '3 rue patrick', 81101, 'Castres', 666787878, 'paul.j@gmail.com', '7890', '1 2     '),
(12345678911, 'Jacques', 'Adit ', '1980-05-19', 'Asthmatique', '3 rue Jean-Paul', 81101, 'Castres', 666777777, 'jacques.a@gmail.com', 'adit', '      ');

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire`
--

CREATE TABLE `questionnaire` (
  `CODEQ` bigint(4) NOT NULL,
  `CODENIR` bigint(13) NOT NULL,
  `DATEQ` date DEFAULT NULL,
  `FIEVRE` varchar(40) NOT NULL,
  `TEMPERATURE` int(11) DEFAULT NULL,
  `MAUXTETE` char(32) DEFAULT NULL,
  `MANQUEAPETIT` char(32) DEFAULT NULL,
  `MODIFICATIONGOUT` char(32) DEFAULT NULL,
  `NAUSEE` char(32) DEFAULT NULL,
  `VOMISSEMENT` char(32) DEFAULT NULL,
  `MAUXESTOMAC` char(32) DEFAULT NULL,
  `CONSTIPATION` char(32) DEFAULT NULL,
  `DIARRHEE` char(32) DEFAULT NULL,
  `ERUPTIONCUTAN` char(32) DEFAULT NULL,
  `PERTESGENIT` char(32) DEFAULT NULL,
  `ZONE` char(32) DEFAULT NULL,
  `AUTRE` char(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `questionnaire`
--

INSERT INTO `questionnaire` (`CODEQ`, `CODENIR`, `DATEQ`, `FIEVRE`, `TEMPERATURE`, `MAUXTETE`, `MANQUEAPETIT`, `MODIFICATIONGOUT`, `NAUSEE`, `VOMISSEMENT`, `MAUXESTOMAC`, `CONSTIPATION`, `DIARRHEE`, `ERUPTIONCUTAN`, `PERTESGENIT`, `ZONE`, `AUTRE`) VALUES
(1, 1111111111111, '2020-03-03', 'severe', 40, 'absent', 'modere  2020-03-01', 'modere  2020-03-01', 'leger  2020-03-01', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', NULL, NULL),
(2, 2222222222222, '2020-03-03', 'modere', 39, 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'severe 2020-03-01', 'absent', 'jambe droite', NULL),
(3, 1111111111111, '2020-05-07', 'absent', 37, 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'peau', 'mal aux jambes'),
(4, 1111111111111, '2020-05-08', 'modere le 2020-04-29', 39, 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', NULL, NULL),
(9, 1111111111111, '2020-05-09', 'absent  ', 38, 'absent', 'leger  2020-04-29', 'absent', 'absent', 'absent', 'severe  2020-05-01', 'absent', 'absent', 'modere  2020-05-05', 'absent', 'torse', 'mal aux jambes'),
(10, 180104101818767, '2020-05-09', 'absent  ', 38, 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', 'absent', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `souffre_de`
--

CREATE TABLE `souffre_de` (
  `CODEP` varchar(128) NOT NULL,
  `CODENIR` bigint(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `souffre_de`
--

INSERT INTO `souffre_de` (`CODEP`, `CODENIR`) VALUES
('hepa', 2222222222222),
('hepa', 180104101818767),
('hepB', 5555555555555),
('mono', 12345678910),
('mono', 1111111111111),
('sal', 12345678911);

-- --------------------------------------------------------

--
-- Structure de la table `specialite`
--

CREATE TABLE `specialite` (
  `CODESPE` varchar(4) NOT NULL,
  `LIBELLE` varchar(128) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `specialite`
--

INSERT INTO `specialite` (`CODESPE`, `LIBELLE`) VALUES
('neu', 'neurologue'),
('ALL', 'Allergologue'),
('INF', 'Infectiologue');

-- --------------------------------------------------------

--
-- Structure de la table `suivre`
--

CREATE TABLE `suivre` (
  `CODEMED` varchar(128) NOT NULL,
  `CODENIR` bigint(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `suivre`
--

INSERT INTO `suivre` (`CODEMED`, `CODENIR`) VALUES
('103', 4444444444444),
('108', 180104101818767),
('1234', 12345678910),
('1234', 12345678911),
('1234', 1111111111111),
('1234', 2222222222222),
('1234', 5555555555555);

-- --------------------------------------------------------

--
-- Structure de la table `traitement`
--

CREATE TABLE `traitement` (
  `CODET` varchar(128) NOT NULL,
  `CODEP` varchar(128) NOT NULL,
  `NOM` varchar(128) DEFAULT NULL,
  `PRINCIPEACTIF` varchar(128) DEFAULT NULL,
  `POSOLOGIE` varchar(128) DEFAULT NULL,
  `RISQUE` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `traitement`
--

INSERT INTO `traitement` (`CODET`, `CODEP`, `NOM`, `PRINCIPEACTIF`, `POSOLOGIE`, `RISQUE`) VALUES
('med1', 'hepa', 'medicament 1', 'Principe Actif', '3 fois pas jour pendant 3 semaines', 3),
('med2', 'mono', 'medicament 2', 'Principe actif', '2 fois par jour pendant 4 semaines', 2),
('med3', 'hepB', 'medicament 3', 'a', '1 fois par jour pendant 1 mois', 3),
('med4', 'sal', 'medicament 4', 'principe 4', '2 fois par jour', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `medecin`
--
ALTER TABLE `medecin`
  ADD PRIMARY KEY (`CODEMED`),
  ADD UNIQUE KEY `I_FK_MEDECIN_SPECIALITE` (`CODESPE`);

--
-- Index pour la table `mensuration`
--
ALTER TABLE `mensuration`
  ADD PRIMARY KEY (`CODEM`),
  ADD KEY `I_FK_MENSURATION_PATIENT` (`CODENIR`);

--
-- Index pour la table `pathologie`
--
ALTER TABLE `pathologie`
  ADD PRIMARY KEY (`CODEP`);

--
-- Index pour la table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`CODENIR`);

--
-- Index pour la table `questionnaire`
--
ALTER TABLE `questionnaire`
  ADD PRIMARY KEY (`CODEQ`),
  ADD KEY `I_FK_QUESTIONNAIRE_PATIENT` (`CODENIR`);

--
-- Index pour la table `souffre_de`
--
ALTER TABLE `souffre_de`
  ADD PRIMARY KEY (`CODEP`,`CODENIR`),
  ADD KEY `I_FK_SOUFFRE_DE_PATHOLOGIE` (`CODEP`),
  ADD KEY `I_FK_SOUFFRE_DE_PATIENT` (`CODENIR`);

--
-- Index pour la table `specialite`
--
ALTER TABLE `specialite`
  ADD PRIMARY KEY (`CODESPE`);

--
-- Index pour la table `suivre`
--
ALTER TABLE `suivre`
  ADD PRIMARY KEY (`CODEMED`,`CODENIR`),
  ADD KEY `I_FK_SUIVRE_MEDECIN` (`CODEMED`),
  ADD KEY `I_FK_SUIVRE_PATIENT` (`CODENIR`);

--
-- Index pour la table `traitement`
--
ALTER TABLE `traitement`
  ADD PRIMARY KEY (`CODET`),
  ADD KEY `I_FK_TRAITEMENT_PATHOLOGIE` (`CODEP`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `mensuration`
--
ALTER TABLE `mensuration`
  MODIFY `CODEM` bigint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `questionnaire`
--
ALTER TABLE `questionnaire`
  MODIFY `CODEQ` bigint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
