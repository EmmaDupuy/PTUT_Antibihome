<?php
	require("connect.php");
	$query = $connexion->prepare("SELECT * FROM `patient` WHERE `CODENIR`=?");
	$query->execute(array($_SESSION["CODENIR"]));
	$patient = $query->fetch();
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
	<title>Profil</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
		<!--Bandeau de navigation-->

        <h1>Profil</h1>
         <div class="onglet">
            <ul>
        		<li><a id="menu1" href ="accueilPatient.php"><abbr title="Accueil"> Accueil </abbr></a></li>
        		<li><a id="menu2" href ="contactPatient.php"><abbr title="Envoyer un message"> Envoyer un message </abbr></a></li>
        		<li><a id="menu3" href ="questionnaire.php"><abbr title="Questionnaire"> Questionnaire </abbr></a></li>
                <li><a class="active" href ="profil_patient.php"><abbr title="Profil"> Mon Profil </abbr></a></li>
                <li><a id="menu5" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
        	</ul>
          </div>
          
         <!--Information profil-->
          
	<div id="cadre">
		<div id="contact-flex">
			<p>Nom :</p>
			<p>
				<?php
					echo utf8_encode($patient['NOM']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Prenom :</p>
			<p>
				<?php
					echo utf8_encode($patient['PRENOM']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>N° sécurité sociale :</p>
			<p>
				<?php
					echo utf8_encode($patient['CODENIR']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Email :</p>
			<p>
				<?php
					echo utf8_encode($patient['MAIL']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Adresse : </p>
			<p>
				<?php
					echo utf8_encode($patient['ADRESSE']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Ville :</p>
			<p>
				<?php
					echo utf8_encode($patient['VILLE']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Code postal :</p>
			<p>
				<?php
					echo utf8_encode($patient['CP']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Date de naissance :</p>
			<p>				<?php
					echo utf8_encode($patient['DATENAISS']);
				?></p>
		</div>
	</div>
	<p><input type="button" value="Modifier" onclick='location.href="modification_profil_patient.php"' /></p>
</body>
</html>