<?php
    if(!isset($connexion)){
        require("connect.php");
    }

    $query = $connexion->prepare("SELECT `JOURQUESTIONNAIRE`, medecin.NOM as med, medecin.POSTE, pathologie.NOM as patho, traitement.NOM as trait, traitement.POSOLOGIE as poso FROM `patient` INNER JOIN `suivre` ON patient.CODENIR= suivre.CODENIR INNER JOIN `medecin` USING (`CODEMED`) INNER JOIN `souffre_de` ON patient.CODENIR= souffre_de.CODENIR INNER JOIN `pathologie` ON souffre_de.CODEP= pathologie.CODEP INNER JOIN `traitement` ON pathologie.CODEP= traitement.CODEP WHERE patient.CODENIR=?");
	$query->execute(array($_SESSION["CODENIR"]));
	$info = $query->fetch();
    $query1 = $connexion->prepare("SELECT `DATEQ` FROM `questionnaire` WHERE `CODENIR`=? AND `DATEQ`=?");
    $query1->execute(array($_SESSION["CODENIR"], date('Y-m-d')));
    $dateq = $query1->fetchAll();

?>
<!DOCTYPE html>
<html>
    <head>
      <title>Accueil</title>
      <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
      <link rel="stylesheet" type="text/css" href="style2.css">
    </head>
    <body>
        <h1>Bonjour <?php echo $_SESSION["nomPat"];?> </h1>
        <div class="onglet">
            <ul>
        		<li><a class="active" id="menu1" href =""><abbr title="Accueil"> Accueil </abbr></a></li>
        		<li><a id="menu2" href ="contactPatient.php"><abbr title="Envoyer un message"> Envoyer un message </abbr></a></li>
        		<li><a id="menu3" href ="questionnaire.php"><abbr title="Questionnaire"> Questionnaire </abbr></a></li>
                <li><a id="menu4" href ="profil_patient.php"><abbr title="Profil"> Mon Profil </abbr></a></li>
                <li><a id="menu5" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
        	</ul>
        </div>
        <div>
            <h2>Bienvenu sur plateforme Antibihome</h2>
            <p>Vous êtes suivit par le medecin <?php  echo($info["POSTE"]." ".$info["med"]) ?> </p>
            <p>Pathologie : <?php  echo($info["patho"]) ?> </p>
            <p>Traitement : <?php  echo($info["trait"]) ?></p>
            <p>Posologie : <?php  echo($info["poso"]) ?></p>
            <?php
    		    if(strpos($info['JOURQUESTIONNAIRE'], date('N')) !== false){
    		        if($dateq == array()){
    		?>
    		<p>Vous devez remplir votre questionnaire</p>
    		<?php
    		        }else{
    		?>
    		<p>Vous avez rempli votre questionnaire du jour</p>
    		<?php
    		        }
    		    }else{
    		        $jours = 7;
    		        for($i=1; $i<8; $i++){
    		            if(strpos($info['JOURQUESTIONNAIRE'], ''.$i) !== false){
    		                if($i < date('N')){
    		                    $j = $i - date('N') + 7;
    		                }else{
    		                    $j = $i - date('N');
    		                }
    		                if($j < $jours){
    		                    $jours = $j;
    		                }
    		            }
    		        }
    		?>
    		<p>prochain questionnaire dans <?php  echo($jours) ?> jours</p>
    		<?php
    		    }
    		?>
        </div>
    </body>
</html>