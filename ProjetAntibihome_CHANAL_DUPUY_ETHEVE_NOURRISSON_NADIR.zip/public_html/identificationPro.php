<?php
ob_start();
// Appel du script de connexion au serveur et � la base de donn�es
	require("connect.php"); 

// On r�cup�re les donn�es saisies dans le formulaire
	$nomSaisi = $_POST["mail"];
	$motPasseSaisi = $_POST["mdp"];

// Si un ou aucun champs n'est rempli
if ($nomSaisi == null or $motPasseSaisi == null){
    	echo "Remplissez les champs, Recommencez SVP..."; 
		header("index.html");
		exit; 
}

// On r�cup�re dans la base de donn�es le mot de passe qui correspond au nom saisi
	$sql = "SELECT mdp FROM medecin WHERE mail='$nomSaisi'";
	$result = $connexion->query($sql) or die("Erreur dans la requete SQL");
	$ligne = $result->fetch();
	$motPasseBdd = $ligne["mdp"];

	// On v�rifie que le mot de passe saisi est identique � celui enregistr� dans la base de donn�es

	if  ($motPasseBdd != $motPasseSaisi)
	// Le mot de passe est diff�rent de celui de la base utilisateur
	{
		echo "Votre saisie est erronée, Recommencez SVP..."; 
		header("index.html");

		// On quitte le script courant sans effectuer les �ventuelles instructions qui suivent
		exit; 
	}
	else
	// Le mot de passe saisi correspond � celui de la base utilisateur
	{
		$sql = "SELECT NOM, CODEMED FROM medecin WHERE mail='$nomSaisi'";
		$result = $connexion->query($sql) or die("Erreur dans la requete SQL");
		$ligne = $result->fetch();
		$_SESSION["nomMed"] = $ligne["NOM"];
		$_SESSION["codeMed"] = $ligne["CODEMED"];

		// Retour vers la page d'entr�e du site

		include("accueilMedecin.php");
		// On quitte le script courant sans effectuer les �ventuelles  instructions qui suivent
		exit;
	}
	
	//on lib�re le jeu d'enregistrement
	$result->closeCursor();
	// on ferme la connexion au SGBD
	mysql_close();
?>