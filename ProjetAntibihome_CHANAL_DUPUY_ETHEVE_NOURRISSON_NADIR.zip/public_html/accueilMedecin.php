<?php
    if(!isset($connexion)){
        require("connect.php");
    }
	
    $query2 = $connexion->prepare("SELECT patient.NOM as nom, patient.PRENOM as prenom, pathologie.NOM as pathologie, pathologie.RISQUE + traitement.RISQUE as r, traitement.NOM as antibiotique, questionnaire.TEMPERATURE as temperature, questionnaire.DATEQ as dateq, questionnaire.MODIFICATIONGOUT as gout, questionnaire.MAUXTETE as tete , questionnaire.MANQUEAPETIT as ap, questionnaire.NAUSEE as nausees, questionnaire.VOMISSEMENT as vomissement, questionnaire.MAUXESTOMAC as estomac , questionnaire.CONSTIPATION as constipation, questionnaire.DIARRHEE as diarrhee, questionnaire.PERTESGENIT as genit, questionnaire.ERUPTIONCUTAN as eruption, questionnaire.ZONE as zone, questionnaire.AUTRE as autre FROM `patient` INNER JOIN `souffre_de` ON patient.CODENIR= souffre_de.CODENIR INNER JOIN `pathologie` ON souffre_de.CODEP= pathologie.CODEP INNER JOIN `traitement` ON traitement.CODEP= pathologie.CODEP INNER JOIN `suivre` ON patient.CODENIR= suivre.CODENIR INNER JOIN `medecin` ON medecin.CODEMED= suivre.CODEMED INNER JOIN `questionnaire` ON questionnaire.CODENIR= patient.CODENIR WHERE medecin.CODEMED=? ORDER BY questionnaire.DATEQ DESC, r DESC");
    $query2->execute(array($_SESSION["codeMed"]));
	$patients = $query2->fetchAll();

    //$query1 = $connexion->prepare("SELECT patient.NOM as nom, patient.PRENOM as prenom, pathologie.NOM as pathologie, pathologie.RISQUE as risque, traitement.NOM as antibiotique, questionnaire.TEMPERATURE as temperature FROM `patient`, `pathologie`, `traitement`, `souffre_de`, `medecin`, `suivre`, `questionnaire` WHERE patient.CODENIR= souffre_de.CODENIR AND souffre_de.CODEP= pathologie.CODEP AND traitement.CODEP= pathologie.CODEP AND medecin.CODEMED= suivre.CODEMED AND suivre.CODENIR= patient.CODENIR AND questionnaire.CODENIR= patient.CODENIR AND medecin.CODEMED=1234" );

	//$p=["paul","pierre"];
	//var_dump($p[0]);
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Accueil</title>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>

    <!-- Barre de notification -->
          <h1>Bonjour Docteur <?php echo $_SESSION["nomMed"];?> </h1>
          <div class="onglet">
            <ul>
                <li><a class="active" href ="accueilMedecin.php"><abbr title="Notification"> Notification </abbr></a></li>
                <li><a class="menu2" href ="liste_patients.php"><abbr title="liste_patient"> Liste des patients </abbr></a></li>
                <li><a class="menu3" href ="profil_medecin.php"><abbr title="profilmédecin"> Profil médecin </abbr></a></li>
            <li><a id="menu4" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
          </ul>
        </div>

	<!--TABLEAU DES BIOLOGIES -->

			<table  border="1" cellspacing="0" cellpadding="20">
			<thead>
                <tr>
                    <th> Nom </th>
                    <th> Prenom </th>
                    <th> Pathologie </th>
                    <th> Antibiotique </th>
                    <th> Symptôme </th>
                    <th> Date questionnaire </th>
                </tr>
            </thead>
            <tbody>
            <?php
             foreach ( $patients as $patient ) 
            {
            ?>
                <tr>
                    <td><?php echo utf8_encode($patient["nom"]);
                    	?></td>
                    <td><?php echo utf8_encode($patient["prenom"]);
                    	?></td>
                     <td><?php echo utf8_encode($patient["pathologie"]);
                        ?></td>
                    <td><?php echo utf8_encode($patient["antibiotique"]);
                        ?></td>
                        
                    <td>
                        <?php 
                            if( (36 > $patient["temperature"]) || $patient["temperature"] > 38) {
                                echo (utf8_encode($patient["temperature"])."°C  </br>"); 
                            } 
                            if(strpos($patient["tete"], "absent") === false)
                                echo "<u>maux de tête :</u> ".$patient["tete"]."</br>";  
                                
                            if(strpos($patient["ap"], "absent") === false)
                                echo "<u>manque appetit :</u> ".$patient["ap"]."</br>"; 
                            
                            if(strpos($patient["gout"], "absent") === false)
                                echo "<u>modification goût :</u> ".$patient["gout"]."</br>";      
                            
                            if(strpos($patient["nausees"], "absent") === false)
                                echo "<u>nausées :</u> ".$patient["nausees"]."</br>";
                                
                            if(strpos($patient["vomissement"], "absent") === false)
                                echo "<u>vomissement :</u> ".$patient["vomissement"]."</br>";
                                
                            if(strpos($patient["estomac"], "absent") === false)
                                echo "<u>maux d'estomac :</u> ".$patient["estomac"]."</br>";
                            
                            if(strpos($patient["constipation"], "absent") === false)
                                echo "<u>constipation :</u> ".$patient["constipation"]."</br>";
                            
                            if(strpos($patient["diarrhee"], "absent") === false)
                                echo "<u>diarrhée :</u> ".$patient["diarrhee"]."</br>";
                                
                            if(strpos($patient["genit"], "absent") === false)
                                echo "<u>pertes génitales :</u> ".$patient["genit"]."</br>";
                                
                            if(strpos($patient["eruption"], "absent") === false)
                                echo "<u>erruption :</u> ".$patient["eruption"]." ".$patient["zone"]."</br>";
                                
                            if($patient["autre"] !== NULL)
                                echo "<u>autre :</u> ".$patient["autre"];
                        ?>
                    </td>
                    <td><?php echo utf8_encode($patient["dateq"]);
                        ?></td>    
                </tr>

            <?php
            	}
            ?>
        	</tbody>
        	</table>

</body>
</html>