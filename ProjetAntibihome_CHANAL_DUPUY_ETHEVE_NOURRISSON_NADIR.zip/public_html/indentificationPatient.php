<?php
ob_start();
// Appel du script de connexion au serveur et � la base de donn�es
	require("connect.php"); 

// On r�cup�re les donn�es saisies dans le formulaire
	$nomSaisi = $_POST["mail"];
	$motPasseSaisi = $_POST["mdp"];
	
// Si un ou aucun champs n'est rempli
if ($nomSaisi == null or $motPasseSaisi == null){
    	echo "Remplissez les champs, Recommencez SVP..."; 
		header("connectPatient.html");
		exit; 
}

// On r�cup�re dans la base de données le mot de passe qui correspond au nom saisi
	$sql = "SELECT mdp FROM patient WHERE mail='$nomSaisi'";
	$result = $connexion->query($sql) or die("Erreur dans la requete SQL");
	$ligne = $result->fetch();
	$motPasseBdd = $ligne["mdp"];

	// On vérifie que le mot de passe saisi est identique à celui enregistré dans la base de données

	if  ($motPasseBdd != $motPasseSaisi)
	// Le mot de passe est différent de celui de la base utilisateur
	{
		echo "Votre saisie est erronée, Recommencez SVP..."; 
		header("connectPatient.html");

		// On quitte le script courant sans effectuer les éventuelles instructions qui suivent
		exit; 
	}
	else
	// Le mot de passe saisi correspond à celui de la base utilisateur
	{
		$sql = "SELECT PRENOM, NOM, CODENIR, MAIL FROM patient WHERE mail='$nomSaisi'";
		$result = $connexion->query($sql) or die("Erreur dans la requete SQL");
		$ligne = $result->fetch();
		$_SESSION["nomPat"] = $ligne["PRENOM"];
		$_SESSION["CODENIR"] = $ligne["CODENIR"];
		$_SESSION["lastNamePat"] = $ligne["NOM"];
        $_SESSION["mailPat"] = $ligne["MAIL"];

		// Retour vers la page d'accueil du site
		
		include("accueilPatient.php");
		ob_end_flush();
		// On quitte le script courant sans effectuer les éventuelles  instructions qui suivent
		exit;
	}
	
	//on libère le jeu d'enregistrement
	$result->closeCursor();
	// on ferme la connexion au SGBD
	mysql_close();
?>








