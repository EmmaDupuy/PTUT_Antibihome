<?php  
	require("connect.php");
	
	$query = $connexion->prepare("SELECT * FROM `patient` WHERE `CODENIR`=?");
	$query->execute(array($_SESSION["CODENIR"]));
	$patient = $query->fetch();
	
	if(isset($_POST["nom"]) || isset($_POST["prenom"]) || isset($_POST["dateN"]) || isset($_POST["adresse"]) || isset($_POST["cp"]) || isset($_POST["ville"]) || isset($_POST["tel"]) || isset($_POST["mail"])){
	    $query1 = $connexion->prepare("UPDATE `patient` SET `nom`=?, `prenom`=?, `dateNaiss`=?, `adresse`=?, `cp`=?, `ville`=?, `telephone`=?, `mail`=? WHERE `CODENIR`=?");
	    $query1->execute(array( $_POST["nom"], $_POST["prenom"], $_POST["dateN"], $_POST["adresse"], $_POST["cp"], $_POST["ville"], $_POST["tel"], $_POST["mail"], $_SESSION["CODENIR"]));
	    include('accueilPatient.php');
	    echo "Votre profil à été modifié.";
	    exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Modifier votre profil</title>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <!--Bandeau de navigation-->

        <h1>Modifier Profil</h1>
         <div class="onglet">
            <ul>
        		<li><a id="menu1" href ="accueilPatient.php"><abbr title="Accueil"> Accueil </abbr></a></li>
        		<li><a id="menu2" href ="contactPatient.php"><abbr title="Envoyer un message"> Envoyer un message </abbr></a></li>
        		<li><a id="menu3" href ="questionnaire.php"><abbr title="Questionnaire"> Questionnaire </abbr></a></li>
                <li><a class="active" href ="profil_patient.php"><abbr title="Profil"> Mon Profil </abbr></a></li>
                <li><a id="menu5" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
        	</ul>
          </div>
        
        <div id = "style"></div>
    	<form action="" method="post">
    		<fieldset>
    			<legend>Informations personnelles</legend>
    			<label for="nom">Nom :</label> <input type="text" name="nom" value=<?php echo $patient["NOM"] ?>><br/>
    			<label for="prenom">Prenom :</label> <input type="text" name="prenom" id="prenom" value=<?php echo $patient["PRENOM"] ?>><br/>
    			<label for="idP">Identifiant patient : </label> <input type="text" name="codenir" id="codenir" value=<?php echo $patient["CODENIR"] ?>  disabled="disabled"><br/>
    			<label for="mail">Email : </label> <input type="email" name="mail" id="mail" value=<?php echo $patient["MAIL"] ?>><br/>
    			<label for="tel">Téléphone : </label> <input type="text" name="tel" id="tel" value=<?php echo $patient["TELEPHONE"] ?>><br/>
    			<label for="adresse">Adresse : </label> <input type="text" name="adresse" id="adresse" value="<?php echo utf8_encode($patient['ADRESSE'])?>"><br/>
    			<label for="ville">Ville : </label> <input type="text" name="ville" id="ville" value=<?php echo $patient["VILLE"] ?>><br/>
    			<label for="cp">Code postal : </label> <input type="text" name="cp" id="cp" value=<?php echo $patient["CP"] ?>><br/>
    			<label for="dateN">Date de naissance : </label> <input type="date" name="dateN" id="dateN" value=<?php echo $patient["DATENAISS"] ?> disabled="disabled"><br/>
    	    <div id = "boutton">
    		    <p><input type="submit" value="Modifier"></p>
    		    <p><input type="button" value="Annuler" onclick='location.href="profil_patient.php"' /></p>
    	    </div>
    	    </fieldset>
    	</form>
	</div>
</body>
</html>