<?php
    require("connect.php");
    $requete=$connexion->prepare('SELECT p.nom as nom, p.prenom as prenom, p.CODENIR as codeNIR, pathologie.NOM as pathologie, traitement.NOM as antibiotique from patient p, pathologie, traitement, souffre_de, medecin, suivre WHERE p.CODENIR = souffre_de.CODENIR AND souffre_de.CODEP = pathologie.CODEP AND traitement.CODEP = pathologie.CODEP AND medecin.CODEMED = suivre.CODEMED AND suivre.CODENIR=p.CODENIR AND medecin.CODEMED=?;' );
    $requete->execute(array($_SESSION["codeMed"]));
    $information=$requete->fetchAll();
    
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
	<title>Liste patients</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<!--Barre de navigation-->

	  <h1>Bonjour Docteur <?php echo $_SESSION["nomMed"];?> </h1>
  <div class="onglet">
	<ul>
		<li><a class="menu1" href ="accueilMedecin.php"><abbr title="Notification"> Notification </abbr></a></li>
		<li><a class="active" href ="liste_patients.php"><abbr title="liste_patient"> Liste des patients </abbr></a></li>
		<li><a class="menu3" href ="profil_medecin.php"><abbr title="profilmédecin"> Profil médecin </abbr></a></li>
    <li><a id="menu4" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
  </ul>
</div>

<!--Tableau -->

	<section>
		<table border="1" cellspacing="0" cellpadding="20">
			<tr>
				<th>Patient</th>
				<th>IdPatient</th>
				<th>Pathologie</th>
				<th>Antibiotique</th>
			</tr>
			<?php
				foreach ($information as $info) {
			?>
			<tr>
				<td><?php echo $info['nom'].' '.$info['prenom'];?></td>
				<td><?php echo $info['codeNIR'];?></td>
                <td><?php echo $info['pathologie'];?></td>
                <td><?php echo $info['antibiotique'];?></td>
			</tr>
			<?php } ?>
		</table>
	</section>

	<div>
		<p><a href="ajouter_nouveau_patient.php"> AJOUTER UN NOUVEAU PATIENT </a> </p>
	</div>
</body>
</html>