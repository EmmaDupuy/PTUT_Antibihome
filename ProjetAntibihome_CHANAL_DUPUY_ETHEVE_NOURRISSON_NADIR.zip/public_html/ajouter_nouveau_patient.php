<?php
require("connect.php");

if(isset($_POST["nom"]) && isset($_POST["codenir"]) && isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["dateN"]) && isset($_POST["antecedent"]) && isset($_POST["adresse"]) && isset($_POST["cp"]) && isset($_POST["ville"]) && isset($_POST["tel"]) && isset($_POST["mail"]) && isset($_POST["codeM"]) && isset($_POST["datem"])  && isset($_POST["poids"]) && isset($_POST["taille"]) && isset($_POST["nomPathologie"]) && isset($_POST["nomtraitement"])){
    
    if(isset($_POST['jour1'])) {
        $jour1 = $_POST['jour1'];
    }else{
        $jour1 = "";
    }
    if(isset($_POST['jour2'])) {
        $jour2 = $_POST['jour2'];
    }else{
        $jour2 = "";
    }
    if(isset($_POST['jour3'])) {
        $jour3 = $_POST['jour3'];
    }else{
        $jour3 = "";
    }
    if(isset($_POST['jour4'])) {
        $jour4 = $_POST['jour4'];
    }else{
        $jour4 = "";
    }
    if(isset($_POST['jour5'])) {
        $jour5 = $_POST['jour5'];
    }else{
        $jour5 = "";
    }
    if(isset($_POST['jour6'])) {
        $jour6 = $_POST['jour6'];
    }else{
        $jour6 = "";
    }
    if(isset($_POST['jour7'])) {
        $jour7 = $_POST['jour7'];
    }else{
        $jour7 = "";
    }
    
	$query1 = $connexion->prepare("INSERT INTO patient VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
	$query1->execute(array($_POST["codenir"], $_POST["nom"], $_POST["prenom"], $_POST["dateN"], $_POST["antecedent"], $_POST["adresse"], $_POST["cp"], $_POST["ville"], $_POST["tel"], $_POST["mail"], $_POST["mdp"], $jour1." ".$jour2." ".$jour3." ".$jour4." ".$jour5." ".$jour6." ".$jour7));

	$query2 = $connexion->prepare("INSERT INTO mensuration VALUES (?,?,?,?,?,?)");
	$query2->execute(array($_POST["codeM"], $_POST["codenir"], $_POST["datem"], $_POST["poids"], $_POST["taille"], $_POST["poids"]/($_POST["taille"]*$_POST["taille"]) ));
    
    $query7 = $connexion->prepare("SELECT CODEP FROM pathologie WHERE NOM=?");
	$query7->execute(array(strtolower($_POST["nomPathologie"])));
	$exist = $query7->fetch();
	
	if($exist == array()){
	    $query3 = $connexion->prepare("INSERT INTO pathologie VALUES (?,?,?)");
	    $query3->execute(array($_POST["codeP"], $_POST["nomPathologie"], $_POST["risqueP"]));
	    $codep = $_POST["codeP"];
	}else{
	    $codep = $exist["CODEP"];
	}

	$query4 = $connexion->prepare("INSERT INTO souffre_de VALUES (?,?)");
	$query4->execute(array($codep, $_POST["codenir"]));
    
    $query8 = $connexion->prepare("SELECT codeT FROM traitement WHERE NOM=?");
	$query8->execute(array(strtolower($_POST["nomtraitement"])));
	$exist1 = $query8->fetchAll();
	
    if($exist1 == array()){
        $query5 = $connexion->prepare("INSERT INTO traitement VALUES (?,?,?,?,?,?)");
	    $query5->execute(array($_POST["codet"],$_POST["codeP"],$_POST["nomtraitement"],$_POST["pActif"],$_POST["posologie"],$_POST["risqueT"]));
	}

	$query6 = $connexion->prepare("INSERT INTO suivre VALUES (?,?)");
	$query6->execute(array($_POST["codeMed"],$_POST["codenir"]));
	include('accueilMedecin.php');
	echo "Vous avez ajouter un nouveau patient";
	exit;
	
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Ajouter un nouveau Patient </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h1>Nouveau patient</h1>
	<form action="" method="post">
		<fieldset>
			<legend>Informations personnelles</legend>
			<label for="nom">Nom :</label> <input type="text" name="nom" id="nom" required /><br/>
			<label for="prenom">Prenom :</label> <input type="text" name="prenom" id="prenom" required /><br/>
			<label for="idP">Identifiant patient : </label> <input type="text" name="codenir" id="codenir" required/><br/>
			<label for="mail">Email : </label> <input type="email" name="mail" id="mail" required /><br/>
			<label for="tel">Téléphone : </label> <input type="number" name="tel" id="tel" required /><br/>
			<label for="adresse">Adresse : </label> <input type="text" name="adresse" id="adresse" required /><br/>
			<label for="adresse">Ville : </label> <input type="text" name="ville" id="ville" required /><br/>
			<label for="adresse">Code postal : </label> <input type="text" name="cp" id="cp" required /><br/>
			<label for="dateN">Date de naissance : </label> <input type="date" name="dateN" id="dateN" required /><br/>
			<label for="antecedent">Antécédents : </label> <input type="text" name="antecedent" id="antecedent" /><br/>
			<label for="mdp">Mot de passe : </label> <input type="text" name="mdp" id="mdp" required /><br/>
			<label for="codeMed">Code du médecin qui le suit : </label> <input type="text" name="codeMed" id="codeMed" value="<?php echo($_SESSION["codeMed"]) ?>" required/><br/>
		</fieldset>
		<fieldset>
			<legend>Mensuration</legend>
			<label for="codeM">code la mensuration: </label> <input type="text" name="codeM" id="codeM" /><br/>
			<label for="datem">Date de la derniere mesure : </label> <input type="date" name="datem" id="datem" /><br/>
			<label for="poids">Poids (kg): </label> <input type="number" step="0.01" name="poids" id="poids" /><br/>
			<label for="taille">Taille (m): </label> <input type="number" step="0.01" name="taille" id="taille" /><br/>
		</fieldset>
		<fieldset>
			<legend>Pathologie</legend>
			<label for="codeP"> Code de la pathologie : </label> <input type="text" name="codeP" id="codeP" /><br/>
			<label for="nomPathologie"> Nom : </label> <input type="text" name="nomPathologie" id="nomPathologie" required  /><br/>
			<label for="risqueP"> Dangerosité : </label> <input type="number" name="risqueP" id="risqueP" min='0' max="10" /><br/>
		</fieldset>
		<fieldset>
			<legend>Traitement</legend>
			<label for="codet">Code traitement : </label> <input type="text" name="codet" id="codet" /><br/>
			<label for="nomtraitement">Nom : </label> <input type="text" name="nomtraitement" id="nomtraitement" required /><br/>
			<label for="pActif">Principe Actif : </label> <input type="text" name="pActif" id="pActif" /><br/>
			<label for="posologie">Posologie : </label> <input type="text" name="posologie" id="posologie" /><br/>
			<label for="risqueT">Dangerosité : </label> <input type="text" name="risqueT" id="risqueT" min='0' max="10" /><br/>
		</fieldset>
		<fieldset>
			<legend>Questionnaire</legend>
				<label for="jour1"> <input type="checkbox" name="jour1" id="jour1" value="1" /> Lundi</label>
				<label for="jour2"> <input type="checkbox" name="jour2" id="jour2" value="2"/> Mardi</label>
				<label for="jour3"> <input type="checkbox" name="jour3" id="jour3" value="3"/> Mercredi</label> 
				<label for="jour4"> <input type="checkbox" name="jour4" id="jour4" value="4"/> Jeudi</label>
				<label for="jour5"> <input type="checkbox" name="jour5" id="jour5" value="5"/> Vendredi</label>
				<label for="jour6"> <input type="checkbox" name="jour6" id="jour6" value="6"/> Samedi</label>
				<label for="jour7"> <input type="checkbox" name="jour7" id="jour7" value="7"/>Dimanche</label>
		</fieldset>
		<div id="style">
			<p><input type="submit" value="Ajouter"></p>
			<p><input type="button" value="Annuler" onclick='location.href="liste_patients.php"' /></p>
		</div>
	</form>
</body>
</html>