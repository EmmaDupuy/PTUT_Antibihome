<?php
	// D�finitions de constantes pour la connexion � MySQL
	define ('SERVEUR', 'localhost'); 
	define ('BASE', 'id13390384_antibihomebdd');
	define ('NOM', 'id13390384_equipe');
	define ('MOTPASSE', 'lequipe-Ptut1');


	// Connexion � la base de donn�es
	try {
			$connexion= new PDO ("mysql:host=".SERVEUR.";dbname=".BASE,NOM,MOTPASSE) ;

	} catch ( Exception $e ) {
		  die ("\n Connection � ".SERVEUR." impossible :  ".$e->getMessage());
	}
session_start();	
?>
