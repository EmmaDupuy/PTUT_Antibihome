<?php
    require("connect.php");
    
    $query = $connexion->prepare("SELECT `JOURQUESTIONNAIRE` FROM `patient` WHERE `CODENIR`=?");
	$query->execute(array($_SESSION["CODENIR"]));
	$jour = $query->fetch();
	
    $query1 = $connexion->prepare("SELECT `DATEQ` FROM `questionnaire` WHERE `CODENIR`=? AND `DATEQ`=?");
    $query1->execute(array($_SESSION["CODENIR"], date('Y-m-d')));
    $dateq = $query1->fetchAll();
    
    if(empty($_POST['zone'])) {
        $zone = NULL;
    }else{
        $zone = $_POST['zone'];
    }
    if(empty($_POST['autre'])) {
        $autre = NULL;
    }else{
        $autre = $_POST['autre'];
    }
    
    if(isset($_POST['mauxDeTete']) && isset($_POST['manqueDapetit']) && isset($_POST['modificationGout']) && isset($_POST['nausees']) && isset($_POST['vomissements']) && isset($_POST['diarree']) && isset($_POST['constipation']) && isset($_POST['geneGenitale']) && isset($_POST['eruption']) && isset($_POST['mauxEstomac']) && isset($_POST['temperature']) && isset($_POST['fievre']) ){
        $query2 = $connexion->prepare("INSERT INTO `questionnaire` VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
    	$query2->execute(array(NULL, $_SESSION['CODENIR'], date('Y-m-d'), $_POST['fievre']."  ".$_POST['dateFievre'], $_POST['temperature'], $_POST['mauxDeTete']."  ".$_POST['dateMauxDeTete'], $_POST['manqueDapetit']."  ".$_POST['dateManqueDapetit'], $_POST['modificationGout']."  ".$_POST['dateModificationGout'], $_POST['nausees']."  ".$_POST['dateNausees'], $_POST['vomissements']."  ".$_POST['dateVomissements'], $_POST['mauxEstomac']."  ".$_POST['dateMauxEstomac'], $_POST['constipation']."  ".$_POST['dateConstipation'], $_POST['diarree']."  ".$_POST['dateDiarree'],  $_POST['geneGenitale']."  ".$_POST['dateGeneGenitale'], $_POST['eruption']."  ".$_POST['dateEruption'], $zone, $autre));
        
        include('accueilPatient.php');
	    echo "Votre questionnaire à été envoyé.";
	    exit;
    }
?>

<!DOCTYPE>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
        <link rel="stylesheet" type="text/css" href="style2.css">
	</head>
	<body> 
	    <h1>Questionnaire</h1>
    	<div class="onglet">
            <ul>
                <li><a id="menu1" href="accueilPatient.php"><abbr title="Accuei">Accueil
                        </abbr></a></li>
                <li><a id="menu2" href="contactPatient.php"><abbr title="Envoyer un message"> Envoyer un message </abbr></a>
                </li>
                <li><a class="active" id="menu3" href="questionnaire.php"><abbr "patientNom"]title="Questionnaire"> Questionnaire </abbr></a></li>
                <li><a id="menu4" href="profil_patient.php"><abbr title="Profil"> Mon Profil </abbr></a></li>
                <li><a id="menu5" href="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
            </ul>
        </div>
		<?php
		    if(strpos($jour['JOURQUESTIONNAIRE'], date('N')) !== false && $dateq == array()){
		?>
		<form action="" method="POST">
			<table>
				<tr>
					<td></td>
					<td>Absent</td>
					<td>Léger</td>
					<td>Modéré</td>
					<td>Sévère</td>
					<td>Début le:</td>
				<tr>
					<td>Maux de tête</td>
					<td><input type="radio" name='mauxDeTete' value="absent"></td>
					<td><input type="radio" name='mauxDeTete' value="leger"></td>
					<td><input type="radio" name='mauxDeTete' value="modere"></td>
					<td><input type="radio" name='mauxDeTete' value="severe"></td>
					<td><input type="date" name="dateMauxDeTete"></td>
				</tr>
				<tr>
					<td>Manque d'apétit</td>
					<td><input type="radio" name='manqueDapetit' value="absent"></td>
					<td><input type="radio" name='manqueDapetit' value="leger"></td>
					<td><input type="radio" name='manqueDapetit' value="modere"></td>
					<td><input type="radio" name='manqueDapetit' value="severe"></td>
					<td><input type="date" name="dateManqueDapetit"></td>
				</tr>
				<tr>
					<td>Modification du goût des aliments</td>
					<td><input type="radio" name='modificationGout' value="absent"></td>
					<td><input type="radio" name='modificationGout' value="leger"></td>
					<td><input type="radio" name='modificationGout' value="modere"></td>
					<td><input type="radio" name='modificationGout' value="severe"></td>
					<td><input type="date" name="dateModificationGout"></td>
				</tr>
				<tr>
					<td>Nausées</td>
					<td><input type="radio" name='nausees' value="absent"></td>
					<td><input type="radio" name='nausees' value="leger"></td>
					<td><input type="radio" name='nausees' value="modere"></td>
					<td><input type="radio" name='nausees' value="severe"></td>
					<td><input type="date" name="dateNausees"></td>
				</tr>
				<tr>
					<td>Vomissements</td>
					<td><input type="radio" name='vomissements' value="absent"></td>
					<td><input type="radio" name='vomissements' value="leger"></td>
					<td><input type="radio" name='vomissements' value="modere"></td>
					<td><input type="radio" name='vomissements' value="severe"></td>
					<td><input type="date" name="dateVomissements"></td>
				</tr>
				<tr>
					<td>Maux d'estomac</td>
					<td><input type="radio" name='mauxEstomac' value="absent"></td>
					<td><input type="radio" name='mauxEstomac' value="leger"></td>
					<td><input type="radio" name='mauxEstomac' value="modere"></td>
					<td><input type="radio" name='mauxEstomac' value="severe"></td>
					<td><input type="date" name="dateMauxEstomac"></td>
				</tr>
				<tr>
					<td>Diarrhées</td>
					<td><input type="radio" name='diarree' value="absent"></td>
					<td><input type="radio" name='diarree' value="leger"></td>
					<td><input type="radio" name='diarree' value="modere"></td>
					<td><input type="radio" name='diarree' value="severe"></td>
					<td><input type="date" name="dateDiarree"></td>
				</tr>
				<tr>
					<td>Constipation</td>
					<td><input type="radio" name='constipation' value="absent"></td>
					<td><input type="radio" name='constipation' value="leger"></td>
					<td><input type="radio" name='constipation' value="modere"></td>
					<td><input type="radio" name='constipation' value="severe"></td>
					<td><input type="date" name="dateConstipation"></td>
				</tr>
				<tr>
					<td>Démangeaisons/pertes génitales</td>
					<td><input type="radio" name='geneGenitale' value="absent"></td>
					<td><input type="radio" name='geneGenitale' value="leger"></td>
					<td><input type="radio" name='geneGenitale' value="modere"></td>
					<td><input type="radio" name='geneGenitale' value="severe"></td>
					<td><input type="date" name="dateGeneGenitale"></td>
				</tr>
				<tr>
					<td>Eruption cutanée allergique</td>
					<td><input type="radio" name='eruption' value="absent"></td>
					<td><input type="radio" name='eruption' value="leger"></td>
					<td><input type="radio" name='eruption' value="modere"></td>
					<td><input type="radio" name='eruption' value="severe"></td>
					<td><input type="date" name="dateEruption"></td>
					<td><input type="text" name="zone" placeholder="zone"></td>
				</tr>
				<tr>
					<td>Trouble de la température</td>
					<td><input type="radio" name='fievre' value="absent"></td>
					<td><input type="radio" name='fievre' value="leger"></td>
					<td><input type="radio" name='fievre' value="modere"></td>
					<td><input type="radio" name='fievre' value="severe"></td>
					<td><input type="date" name="dateFievre"></td>
					<td><input type="number" name="temperature" placeholder="température" value="37.5"></td>
				</tr>
			    <tr>
					<td>Autre</td>
					<td><input type="textarea" name="autre"></td>
				</tr>
			</table>
			<input type="submit" value="Valider">
		</form>
		<?php
		    } else{
                echo "Vous n'avez pas de questionnaire à remplir aujourd'hui ou vous avez déjà effectué cette tâche";
            }
        ?>
	</body>
</html>
