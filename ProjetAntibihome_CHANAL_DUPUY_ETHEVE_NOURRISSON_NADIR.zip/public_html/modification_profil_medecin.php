<?php
    require("connect.php");
	$query = $connexion->prepare("SELECT * FROM `medecin` WHERE `CODEMED`=?");
	$query->execute(array($_SESSION["codeMed"]));
	$medecin = $query->fetch();
	
	if(isset($_POST["poste"]) || isset($_POST["poste"]) || isset($_POST["nom"]) || isset($_POST["prenom"]) || isset($_POST["mail"])){
	    $query1 = $connexion->prepare("UPDATE `medecin` SET `POSTE`=?, `NOM`=?, `PRENOM`=?, MAIL=? WHERE `CODEMED`=?;");
	    $query1->execute(array( $_POST["poste"], $_POST["nom"], $_POST["prenom"], $_POST["mail"], $_SESSION["codeMed"]));
	    include("accueilMedecin.php");
	    exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
	<title>Modifier votre profil</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!--Barre de navigation-->

	  <h1>Bonjour Docteur <?php echo $_SESSION["nomMed"];?> </h1>
  <div class="onglet">
	<ul>
		<li><a class="menu1" href ="accueilMedecin.php"><abbr title="Notification"> Notification </abbr></a></li>
		<li><a class="menu2" href ="liste_patients.php"><abbr title="liste_patient"> Liste des patients </abbr></a></li>
		<li><a class="active" href ="profil_medecin.php"><abbr title="profilmédecin"> Profil médecin </abbr></a></li>
    <li><a id="menu4" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
  </ul>
</div>

	<form action="" method="post">
		<fieldset>
			<legend>Informations personnelles</legend>
			<label for="nom">Nom :</label> <input type="text" name="nom" id="nom" value=<?php echo $medecin["NOM"] ?>><br/>
			<label for="prenom">Prenom :</label> <input type="text" name="prenom" id="prenom" value=<?php echo $medecin["PRENOM"] ?>><br/>
			<label for="codeMed">Identifiant médecin : </label> <input type="text" name="codeMed" id="codeMed" value=<?php echo $medecin["CODEMED"] ?> disabled="disabled"><br/>
			<label for="mail">Email : </label> <input type="email" name="mail" id="mail" value=<?php echo $medecin["MAIL"] ?>><br/>
			<label for="poste">Poste : </label> <input type="text" name="poste" id="poste" value=<?php echo $medecin["POSTE"] ?>  disabled="disabled"><br/>
	<div id = "submit">
		<p><input type="submit" value="Modifier" name="submit"></p>
		<p><input type="button" value="Annuler" onclick='location.href="profil_medecin.php"' /></p>
	</div>
	
	</form>
</body>
</html>