<?php
	require("connect.php");
	$query = $connexion->prepare("SELECT * FROM `medecin` WHERE `CODEMED`=?");
	$query->execute(array($_SESSION["codeMed"]));
	$medecin = $query->fetch();
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
	<title>Profil</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<!--Barre de navigation-->

		<h1>Bonjour Docteur <?php echo $_SESSION["nomMed"];?> </h1>
		  <div class="onglet">
			<ul>
				<li><a class="menu1" href ="accueilMedecin.php"><abbr title="Notification"> Notification </abbr></a></li>
				<li><a class="menu2" href ="liste_patients.php"><abbr title="liste_patient"> Liste des patients </abbr></a></li>
				<li><a class="active" href ="profil_medecin.php"><abbr title="profilmédecin"> Profil médecin </abbr></a></li>
		    <li><a id="menu4" href ="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
		  </ul>
		</div>

<!--Profil de médecin-->

	<div id="cadre">
		<div id="contact-flex">
			<p>Nom :</p>
			<p>
				<?php
					echo utf8_encode($medecin['NOM']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Prenom :</p>
			<p>
				<?php
					echo utf8_encode($medecin['PRENOM']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Identifiant médecin :</p>
			<p>
				<?php
					echo utf8_encode($medecin['CODEMED']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Email :</p>
			<p>
				<?php
					echo utf8_encode($medecin['MAIL']);
				?>
			</p>
		</div>
		<div id="contact-flex">
			<p>Poste : </p>
			<p>
				<?php
					echo utf8_encode($medecin['POSTE']);
				?>
			</p>
		</div>
	</div>
	<p><input type="button" value="Modifier" onclick='location.href="modification_profil_medecin.php"' /></p>
</body>
</html>