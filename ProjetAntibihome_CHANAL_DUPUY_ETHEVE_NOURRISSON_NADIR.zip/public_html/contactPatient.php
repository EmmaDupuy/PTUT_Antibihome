  <?php
  
    require("connect.php");
    $query = $connexion->prepare("SELECT `MAIL` FROM `medecin` WHERE `CODEMED`= (SELECT `CODEMED` FROM `suivre` WHERE `CODENIR`=?);");
	$query->execute(array($_SESSION["CODENIR"]));
    $ligne = $query->fetch();
    $mail = $ligne['MAIL'];
    if (isset($_POST['message'])) {
            $retour = mail($mail, $_POST['objet'], $_POST['message'], 'From: ' . $_SESSION["mailPat"]);
            if($retour)
                echo '<p>Votre message a été envoyé.</p>';
            else
                echo '<p>Erreur.</p>';
        }
    
?>
<!DOCTYPE html>
<html>

<head>
    <title>Contacter votre medecin</title>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>

<body>
    <h1>Contact</h1>
    <div class="onglet">
        <ul>
            <li><a id="menu1" href="accueilPatient.php"><abbr title="Accueil"> Accueil
                    </abbr></a></li>
            <li><a class="active" id="menu2" href="contactPatient.php"><abbr title="Envoyer un message"> Envoyer un message </abbr></a>
            </li>
            <li><a id="menu3" href="questionnaire.php"><abbr "patientNom"]title="Questionnaire"> Questionnaire </abbr></a></li>
            <li><a id="menu4" href="profil_patient.php"><abbr title="Profil"> Mon Profil </abbr></a></li>
            <li><a id="menu5" href="deconnect.php"><abbr title="Deconnexion"> Deconnexion </abbr></a></li>
        </ul>
    </div>

    <div id="formulaireMessagerie">
        <h3 class="contactPatient">Envoyer un message</h3>
        <form method="post" id="formmessage">
            <label>Objet :</label>
            <input type="text" name="objet" required><br><br>
            <label>Message : </label>
            <textarea name="message" required></textarea><br><br>
            <p>*Pensez à signer votre mail.*</p>
            <input type="submit">
        </form>
    </div>
    <div id="photographier">
        <h3 class="contactPatient">Prendre une photo</h3><!-- The buttons to control the stream -->
        <div class="button-group" id="button-group">
            <button id="btn-start" type="button" class="button">Allumer la webcam</button>
            <button id="btn-capture" type="button" class="button">Photographier</button>
            <button id="btn-stop" type="button" class="button">Eteindre la webcam</button>

        </div>

        <!-- Video Element & Canvas -->
        <div class="play-area" id="play-area">

            <div class="play-area-sub" id="play-area-sub1">

                <video id="stream" width="320" height="240"></video>
            </div>
            <div class="play-area-sub" id="play-area-sub2">

                <canvas id="capture" width="320" height="240"></canvas>
                <div id="snapshot" title="Pour enregistrer l&apos;image, faire clic droit, puis cliquer sur &quot;Enregistrer l&apos;image sous&quot;."></div>
            </div>
        </div>
    </div>

    <!--source : https://html5.tutorials24x7.com/blog/how-to-capture-image-from-camera-->
    <script src="scriptcamera.js"></script>
</body>

</html>